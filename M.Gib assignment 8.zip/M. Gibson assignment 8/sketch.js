var img;
var nope;

let r ='holy  crud  is  that ';
let b ='                           A TF2 REFERENCE?!';

function preload(){
  img = loadImage("snooper.jpg");
	nope = loadImage("MiningLight.png")
}

function setup() {
  createCanvas(600,500);
background(0);

  textFont("Arial");
fill(232,9,5);
stroke(255);
  textSize(32);
  text(r,0,370,300,500);
}

function draw() {
	

  image(img,0,0,mouseX * 2);

  image(nope,300,200,mouseY);
  


textFont("Monoton");
fill(0,123,255);
stroke(255);
textSize(35);
text(b,0,420,300,500);
}

//I program my own memes