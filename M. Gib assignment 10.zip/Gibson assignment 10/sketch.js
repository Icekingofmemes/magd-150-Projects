let vid;
function setup() {
 createCanvas(600,400);
background(125);
  vid = createVideo(
  	['assets/nope.avi.mp4','assets/nope.avi.ogv','nope.avi.webm','assets/family.mp4'],
  	vidLoad
  	);

  vid.size(400,350);
};
function draw(){
textSize(45);
stroke(232,66,12);
fill(41,12,232);
text(' Holy crud is that a TF2 ',10,50);
text('reference?!', 10, 105);
};
function vidLoad() {
	vid.loop();
	vid.volume(0);
};