var mic;
var amp;

var sine;
var freq = 420;

var q;

var slap;

var radius = 120;
var t = 0;
var speed = 1.0;
var direction = 1;

var capture;




function preload(){
	slap = loadSound("Slap.wav");
}

function setup() {

 createCanvas(600,400);

capture = createsCapture();
capture.hide();

ellipseMode(RADIUS);
t = width/2;

 mic = new p5.AudioIn();
 mic.start();

amp = new p5.Amplitude();
amp.setInput(mic);

sine = new p5.SinOsc();
sine.start();
};

function draw() {
	 background(153);

//camera  ( I don't own a webcam on my pc)
var aspectRatio = capture.height/capture.width;
var h = width * aspectRatio;
image(capture, 0,0,width,h);
filter(GRAY);

//slapman
	 t += speed * direction;
	 if ((x > width-radius) || (x < radius)) {
	 	direction = -direction;
	 	slap.play();
	 }

	 if (direction == 1) {
	 	arc(x,220,radius,radius,0.52,5.76);
	 }else{
	 	arc(x,220,radius,radius,3.67,8.9);
	 }
//oscilator

	 var hertz = map(mouseX,0,width,20.0,440.0);
	 sine.freq(hertz);

	 stroke(204);

	 for(var x = 0; x < width; x++){
	 	var angle = map(x,0,width,0,TWO_PI * hertz);

	 	var sinValue = sin(angle) *120;

	 	line(x,0,x,height/2 + sinValue);
	 }
	noStroke();
	fill(0,10);
	rect(0,0,width,height);


//greendot
	q = map(amp.getLevel(),0,1.0,10,width);
		fill(1,255,8);
		rect(width/4,height/4,q,q)
};